redis-ratelimit
===============

Java port of [RateLimit from chriso/redback](https://github.com/chriso/redback/blob/master/lib/advanced_structures/RateLimit.js) node.js library.


To install:

    mvn clean install

To use:

    <dependency>
      <groupId>com.sentaca</groupId>
      <artifactId>redis-ratelimit</artifactId>
      <version>1.0-SNAPSHOT</version>
    </dependency>
