package de.ahus1.hystrix.base;

public class AbstractSaveAccount {

    public void saveToDatabase(Account account) {
        // NOP
    }
}
