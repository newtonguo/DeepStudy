package de.ahus1.hystrix.base;

public class ValidationException extends Exception {

    public ValidationException(String string) {
        super(string);
    }

}
