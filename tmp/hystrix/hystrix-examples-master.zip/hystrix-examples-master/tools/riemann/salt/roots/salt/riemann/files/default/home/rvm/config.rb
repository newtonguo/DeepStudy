set :port, 4567      # HTTP server on port 6000
set :bind, "0.0.0.0" # Bind to a different interface
config[:ws_config] = 'custom/config.json'

