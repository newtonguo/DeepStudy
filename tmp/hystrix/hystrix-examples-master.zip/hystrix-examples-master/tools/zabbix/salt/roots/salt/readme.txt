These pillars have been taken from 

https://github.com/moreda

The initial scripts have been developed for Debian/Ubuntu style systems. 

There are some local changes to adopt it to CentOS (there will be a merge request soon).

Br,
Alex.