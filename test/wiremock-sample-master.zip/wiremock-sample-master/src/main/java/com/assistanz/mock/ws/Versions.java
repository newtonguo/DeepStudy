package com.assistanz.mock.ws;

import java.util.ArrayList;

/**
 * List of Version.
 *
 * @author Sujai SD <sujai@assistanz.com>
 */
public class Versions extends ArrayList<Version> {

}
