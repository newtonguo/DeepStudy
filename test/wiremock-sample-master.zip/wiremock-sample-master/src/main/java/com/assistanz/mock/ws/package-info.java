/**
 * HTTP Mockup testing library.
 */
package com.assistanz.mock.ws;
