package com.deswaef.netflixexamples.api.infrastructure;

public class Collaborators {
    public static final String NOTIFICATIONS = "notification-service";
}
