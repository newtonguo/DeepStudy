# Spring Boot Netflix Examples - Part 1: Eureka

> This is a repository accompanying the blogpost posted at https://blog.de-swaef.eu/the-netflix-stack-using-spring-boot/

# Spring Boot Netflix Examples - Part 2: Hystrix

> This is a repository accompanying the blogpost posted at https://blog.de-swaef.eu/the-netflix-stack-using-spring-boot-part-2-hystrix/

# Spring Boot Netflix Examples - Part 3: Feign

> This is a repository accompanying the blogpost posted at https://blog.de-swaef.eu/the-netflix-stack-using-spring-boot-part-3-feign/
