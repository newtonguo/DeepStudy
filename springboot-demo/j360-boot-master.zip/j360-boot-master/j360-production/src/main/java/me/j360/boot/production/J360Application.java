package me.j360.boot.production;

import org.springframework.boot.SpringApplication;

/**
 * Created with springbootweb -> me.j360.springboot.jar.
 * User: min_xu
 * Date: 2015/7/28
 * Time: 15:28
 * 说明：
 */
public class J360Application {
    public static void main(String[] args) {
        SpringApplication.run(J360Configuration.class, args);
    }


}
