BTrace is a safe, dynamic tracing system for the Java platform. BTrace project 
is hosted at http://kenai.com/projects/btrace. See also "docs" directory.

BTrace是Java平台的一个安全、动态的追踪工具。
BTrace项目托管在http://kenai.com/projects/btrace
见"文档(docs)"目录