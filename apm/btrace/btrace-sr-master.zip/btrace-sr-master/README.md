# btrace-sr
[BTrace](https://kenai.com/projects/btrace) 实战学习笔记，其号称“线上问题追踪神器”。
