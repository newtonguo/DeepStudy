package com.hg.db.mysql.binlog.entity;

/**
 * Created by wangqinghui on 2015/12/17.
 */
public class BasicC2s {
    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
