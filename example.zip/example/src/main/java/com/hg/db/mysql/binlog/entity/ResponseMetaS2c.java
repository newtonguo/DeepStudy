package com.hg.db.mysql.binlog.entity;

/**
 * Created by wangqinghui on 2015/12/17.
 */
public class ResponseMetaS2c {
        public String code;
        public String message;
        public String getCode() {
            return code;
        }
        public void setCode(String code) {
            this.code = code;
        }
        public String getMessage() {
            return message;
        }
        public void setMessage(String message) {
            this.message = message;
        }


}
